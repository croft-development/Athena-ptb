const open = require("open");
const os = require('os');
const path = require('path');
const url = require('url');
const DiscordRPC = require('discord-rpc');
const fs = require('fs');
const parse = require('parse-duration')
const moment = require('moment')

var ClientId
if (config.serviceConfig.customClientID == 'none') {
  ClientId = "566578055246512128";
} else {
  ClientId = config.serviceConfig.customClientID
}
DiscordRPC.register(ClientId);

const rpc = new DiscordRPC.Client({
  transport: 'ipc'
});

var oldID
var oldState
async function setActivity() {
  if (!rpc || (config.serviceConfig.useUserInterface == true && !mainWindow))
    return;
}
  var activity = {
    largeImageKey: 'microphone',
    largeImageText: 'Athena',
    state: 'Using commands',
    instance: false
  }
  if (config.serviceConfig.useTimestamps == true) {

    if (rtn.position) {

      activity.startTimestamp = moment(time).subtract(rtn.position, 's').toDate()

      if (rtn.duration) {

        activity.endTimestamp = moment(time).add(rtn.duration - rtn.position, 's').toDate()

      }

    } else if ((oldID !== rtn.id || !oldID) && rtn.duration) {

      activity.startTimestamp = moment(time).subtract('0', 's').toDate()

      activity.endTimestamp = moment(time).add(rtn.duration - 0, 's').toDate()

    }

  }

  if (rtn.state !== 'paused') {

    if (rtn.loved == false) {

      activity.smallImageKey = undefined

      activity.smallImageText = undefined

    } else {

      activity.smallImageKey = 'icon-heart'

      activity.smallImageText = 'Loved'

    }

  } else {

    activity.smallImageKey = 'icon-pause'

    activity.smallImageText = 'Paused'

    activity.startTimestamp = undefined

    activity.endTimestamp = undefined

    //activity.endTimestamp = moment(time).add('0', 's').toDate();

    //activity.startTimestamp = moment(time).add('-' + rtn.position, 's').toDate();

  }



  if (!oldID) {

    oldID = rtn.id

    oldState = rtn.state

    console.log(`[${new Date().toLocaleTimeString()}]: Initialised Successfully.`);

    rpc.setActivity(activity);

  }

  if (oldID !== rtn.id || oldState !== rtn.state) {
    oldID = rtn.id
    oldState = rtn.state
    console.log(`[${new Date().toLocaleTimeString()}]: Status Change Detected, updating Rich Presence.`)
   rpc.setActivity(activity);
}

setActivity(activity);

rpc.login({clientId: ClientId}).catch(console.error);