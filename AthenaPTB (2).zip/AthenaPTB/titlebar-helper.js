const { remote } = require('electron')
var maximized=false
function end() {
  var window = remote.getCurrentWindow();
  window.close();
};
function min() {
  remote.BrowserWindow.getFocusedWindow().minimize();
  console.log("minimize")
};
function max() {
  if (maximized) {
    console.log("unmaximize")
    remote.BrowserWindow.getFocusedWindow().unmaximize();
    maximized = false
  } else {
    console.log("maximize")
    remote.BrowserWindow.getFocusedWindow().maximize();
    maximized = true
  }
}
/* MAximizing now! */
