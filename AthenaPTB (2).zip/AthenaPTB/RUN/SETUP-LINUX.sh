set +v
clear
echo Installing
npm i discord-rpc electron-packager electron express swearing-is-bad moment path url weather-js