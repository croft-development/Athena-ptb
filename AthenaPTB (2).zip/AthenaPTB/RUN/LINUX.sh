set +v
clear
echo Starting
cd..
npm start