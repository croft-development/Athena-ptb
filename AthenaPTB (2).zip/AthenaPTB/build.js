var electronInstaller = require('electron-winstaller');

// In this case, we can use relative paths
var settings = {
    // Specify the folder where the built app is located
    appDirectory: './Athena-win32-x64',
    // Specify the existing folder where 
    outputDirectory: './athena-installer',
    // The name of the Author of the app (the name of your company)
    authors: 'iON Development, Croft',
    // The name of the executable of your built
    exe: './athena.exe'
};

resultPromise = electronInstaller.createWindowsInstaller(settings);
 
resultPromise.then(() => {
    console.log("The installers of your application were succesfully created !");
}, (e) => {
    console.log(`Your pc must hate you... Error: ${e.message}`)
});