var errorCount=0;
function writeAnswer(inString) {
  try {
    responsiveVoice.speak(inString);
  }
  catch ( error ) {
    console.log("Couldnt execute responsive voice.\nAre you connected to the internet?")
  }
  document.getElementById("answer").innerHTML = inString;
}

function check() {
  var fs = require('fs');
  var textboxValue = document.getElementById("textbox").value.toLowerCase();
  dataSet(textboxValue);
  var weather = require('weather-js');
  // Say command
  if (textboxValue.startsWith('say ')) {
      let text = textboxValue.slice(4);
      writeAnswer(text);
    } else if (textboxValue.includes('weather')) {
      let searched = textboxValue.split('weather ')[1];
      // Weather for/in/at
      if (searched.startsWith('for')) {
        searched = searched.trim(4)
      }
      if (searched.startsWith('in')) {
        searched = searched.trim(3)
      }
      if (searched.startsWith('at')) {
        searched = searched.trim(3)
      }
      // Invalid Location
      weather.find({search: searched, degreeType:'C'}, function(err, result) {
        if(result.length == 0) {
          writeAnswer('Sorry, I don\'t know that location.');
          return;
        }
        var current  = result[0].current
        var forecast = current.forecast
        // Excute weather
        document.getElementById("answer").innerHTML = `${current.observationpoint} <br> Temperature: ${current.temperature}°c. <br>  Wind: ${current.winddisplay}. <br> Humidity: ${current.humidity}%. <br> It feels like: ${current.feelslike}°c.`;
        responsiveVoice.speak(`The current weather in ${current.observationpoint} is <br> Temperature: ${current.temperature}°c. <br>  Wind: ${current.winddisplay}. <br> Humidity: ${current.humidity}%. <br> It feels like: ${current.feelslike}°c.`);
        lastcommand = `weather${searched}`;
      })
    // Coin flip
    } else if ((textboxValue.includes('flip')) && (textboxValue.includes ('coin')) || (textboxValue.includes('heads')) && (textboxValue.includes('tails'))) {
      if (Math.floor(Math.random() * 2) == 0) {
        writeAnswer(randomString()+"heads.");
      } else {
        writeAnswer(randomString()+"tails.");
      }
      function randomString() {
        x = Math.floor(Math.random() * 3);
        if (x == 0) {
          return "Looks like the coin landed on ";
        } else if (x == 1) {
          return "The coin landed on ";
        } else if (x == 2) {
          return "I flipped a coin, it landed on ";
        } else {
          return "It landed on ";
        }
      }
    // Date or time?
    } else if (textboxValue.includes('time')||textboxValue.includes('date')) {
      writeAnswer(Date());
    // Hello/Hey/Hi
    } else if (textboxValue.includes('hello')||textboxValue.includes('hey')||textboxValue.includes('hi')) {
      writeAnswer('Hello, and welcome to Athena AI.');
    // There is a bug/i have some feedback/i have a question
    } else if (textboxValue.includes('bug')||textboxValue.includes('feedback')||textboxValue.includes('question')) {
      writeAnswer("If you have any questions, feedback or bugs email contactcroftofficial@gmail.com");
    } else if (textboxValue.includes('goodbye')||textboxValue.includes('exit')||textboxValue.includes('leave')) {
      responsiveVoice.speak("Shutting down...")
      var window = remote.getCurrentWindow();
      window.close();
    // What do you do?
    } else if (textboxValue.includes('what')&&textboxValue.includes('you')&&textboxValue.includes('do'))  {
      writeAnswer("I can do all sorts of things, for example get the time or flip a coin.");
    // Big Chungus
    } else if (textboxValue.includes('big')&&textboxValue.includes('chungus')) {
      writeAnswer("I'm sorry, but Big Chungus is a dead meme.");
    // Roll a dice
    } else if (textboxValue.includes('roll')||textboxValue.includes ('dice')) {
      function roll() {
        x = Math.floor(Math.random() * 3);
        result = Math.floor(Math.random() * 5) + 1

        if (x == 0) {
          writeAnswer("Looks like the dice stopped on " + result);
        } else if (x == 1) {
          writeAnswer("The dice stopped on " + result);
        } else if (x == 2) {
          writeAnswer("I rolled a dice, it landed on " + result);
        } else {
          writeAnswer("The dice landed on " + result);
        }
      }
      roll()
    // Who are you? / What is you name?
    } else if ((textboxValue.includes('who')&&textboxValue.includes('you'))||(textboxValue.includes('what')&&textboxValue.includes('name'))) {
      writeAnswer("My name is Athena, and I was developed by CROFT & ION.");
    // Help
    } else if (textboxValue.includes('help')) {
      writeAnswer('Sure, what do you need?');
    // OwO
    } else if (textboxValue.includes('owo')) {
      responsiveVoice.speak("ooh woo");
      document.getElementById("answer").innerHTML = 'UwU';
    // Doesn't know that command
    } else {
        writeAnswer('Sorry I don\'t know that.');
      }
    document.getElementById("textbox").value = '';
    }
    // Press enter
    var input = document.getElementById("textbox");
    input.addEventListener("keydown", function(event) {
    if (event.keyCode === 13) {
      event.preventDefault();
      check();
    }
  });

// JSON Data collection
function dataSet(inString) {
  if ( localStorage.length == 0 ) {
    localStorage.setItem("recentCommands", JSON.stringify([]))
  }
  var list = JSON.parse(localStorage.getItem("recentCommands"));
  for(var i = list.length; i--; i>0) {
    list[i+1]=list[i];
  }
  list[0]=inString;
  localStorage.setItem("recentCommands",JSON.stringify(list))
}
